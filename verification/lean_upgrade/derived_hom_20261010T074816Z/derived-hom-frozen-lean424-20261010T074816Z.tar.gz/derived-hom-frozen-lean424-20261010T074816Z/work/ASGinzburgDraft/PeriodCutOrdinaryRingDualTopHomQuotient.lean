import work.ASGinzburgDraft.GradedOrdinaryRingDualHomogeneousTopQuotientType
import work.ASGinzburgDraft.OrdinaryRingDualCanonicalFieldStructures
import work.ASGinzburgDraft.PeriodCutGradedHomCanonicalFieldStructures
import work.ASGinzburgDraft.PeriodCutOrdinaryRingDualShiftedHomNaturality
import work.ASGinzburgDraft.LinearCokernelSquareEquiv

/-! The actual homogeneous ordinary ring-dual top quotient is the
actual shifted regular Hom quotient, via the genuine precomposition square. -/
namespace ASGinzburg.ZAlgebra.PeriodIso
open CategoryTheory
open scoped ModuleCat.Algebra
attribute [local instance 3000] ASGinzburg.GradedOrdinaryModuleData.ringDualGradeHasQuotient
attribute [local instance 4000] ASGinzburg.ordinaryRingDualUnbundledAddCommGroup
universe u v
set_option maxHeartbeats 200000
set_option synthInstance.maxHeartbeats 100000
variable {k : Type u} [Field k] {A : ZAlgebra.{u,v} k}
variable (Q : CutQuiver) (E : A.PeriodIso (Q.vertices : ℤ))
variable {M L : E.CutGradedRightModule Q}

attribute [local instance 4000] cutOrdinaryRingDualTopHomAddCommGroup
attribute [local instance 4000] cutOrdinaryRingDualTopHomFieldModule

noncomputable def cutOrdinaryRingDualTopShiftedHomQuotientEquiv
    (a : M ⟶ L) (q : ℤ) :
    (E.cutRightModuleOrdinaryData Q M).ringDualHomogeneousTopQuotient
        (E.cutRightModuleOrdinaryData Q L) ((E.cutGradedForgetFunctor Q).map a)
        (E.cutRightModuleOrdinaryMap_preservesGrade Q a) q ≃ₗ[k]
      ((M ⟶ (E.cutRegularGradedRightModule Q).shifted q) ⧸
        LinearMap.range (Linear.leftComp k
          ((E.cutRegularGradedRightModule Q).shifted q) a)) := by
  let DM := E.cutRightModuleOrdinaryData Q M
  let DL := E.cutRightModuleOrdinaryData Q L
  let f : DL.ringDualGrade q →ₗ[k] DM.ringDualGrade q :=
    DM.ringDualMapDegree DL ((E.cutGradedForgetFunctor Q).map a)
    (E.cutRightModuleOrdinaryMap_preservesGrade Q a) q
  let g : (L ⟶ (E.cutRegularGradedRightModule Q).shifted q) →ₗ[k]
      (M ⟶ (E.cutRegularGradedRightModule Q).shifted q) :=
    Linear.leftComp k ((E.cutRegularGradedRightModule Q).shifted q) a
  let eM : DL.ringDualGrade q ≃ₗ[k]
      (L ⟶ (E.cutRegularGradedRightModule Q).shifted q) :=
    E.cutOrdinaryRingDualShiftedHomEquiv Q L q
  let eN : DM.ringDualGrade q ≃ₗ[k]
      (M ⟶ (E.cutRegularGradedRightModule Q).shifted q) :=
    E.cutOrdinaryRingDualShiftedHomEquiv Q M q
  have h : ∀ x, eN (f x) = g (eM x) := by
    intro x
    exact E.cutOrdinaryRingDualShiftedHomEquiv_precomp Q a q x
  have hr : (LinearMap.range f).map eN.toLinearMap = LinearMap.range g := by
    ext y
    rw [Submodule.mem_map]
    constructor
    · rintro ⟨z, hz, rfl⟩
      obtain ⟨x, rfl⟩ := hz
      exact ⟨eM x, (h x).symm⟩
    · rintro ⟨x, rfl⟩
      refine ⟨f (eM.symm x), ⟨eM.symm x, rfl⟩, ?_⟩
      change eN (f (eM.symm x)) = g x
      rw [h, eM.apply_symm_apply]
  let e := Submodule.Quotient.equiv (LinearMap.range f) (LinearMap.range g) eN hr
  exact e

@[simp] theorem cutOrdinaryRingDualTopShiftedHomQuotientEquiv_mk
    (a : M ⟶ L) (q : ℤ) (f : (E.cutRightModuleOrdinaryData Q M).ringDualGrade q) :
    E.cutOrdinaryRingDualTopShiftedHomQuotientEquiv Q a q
      ((LinearMap.range (τ₁₂ := RingHom.id k)
        ((E.cutRightModuleOrdinaryData Q M).ringDualMapDegree
        (E.cutRightModuleOrdinaryData Q L) ((E.cutGradedForgetFunctor Q).map a)
        (E.cutRightModuleOrdinaryMap_preservesGrade Q a) q)).mkQ f) =
      (LinearMap.range (Linear.leftComp k
        ((E.cutRegularGradedRightModule Q).shifted q) a)).mkQ
          (E.cutOrdinaryRingDualShiftedHomEquiv Q M q f) := rfl

end ASGinzburg.ZAlgebra.PeriodIso
