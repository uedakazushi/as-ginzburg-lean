import work.ASGinzburgDraft.PeriodCutNativeTopCoverConeDetection
import work.ASGinzburgDraft.GradedOrdinaryTopCoverConeCoverIso

/-! Genuine semisimple reduction concentrated at the top implies low
exactness and projectivity of the actual top cokernel. -/
namespace ASGinzburg.ZAlgebra.PeriodIso
open CategoryTheory CategoryTheory.Limits
open scoped ModuleCat.Algebra
universe u v
variable {k : Type u} [Field k] {A : ZAlgebra.{u,v} k}
variable (Q : CutQuiver) (E : A.PeriodIso (Q.vertices : ℤ))
local notation "R" => E.CutGradedRing (fun i : Q.Vertex => (Fin.val i : ℤ))
local notation "F" => balancedTensorLeftFunctor k R (R ⧸ E.cutGradedJacobson Q)
local notation "D" => GradedOrdinaryModuleData k Rᵐᵒᵖ (E.cutIntegerOppositeHomogeneousSpace Q)

theorem cutGradedTensor_lowExact_topCokernel_projective
    (P₀ P₁ P₂ P₃ : D) (b : ℤ)
    (hb₀ : P₀.BoundedBelow b) (hb₁ : P₁.BoundedBelow b)
    (hb₂ : P₂.BoundedBelow b) (hb₃ : P₃.BoundedBelow b)
    (f₀ : P₀.ringModule ⟶ P₁.ringModule)
    (f₁ : P₁.ringModule ⟶ P₂.ringModule) (f₂ : P₂.ringModule ⟶ P₃.ringModule)
    (h₀ : f₀ ≫ f₁ = 0) (h₁ : f₁ ≫ f₂ = 0)
    (hf₀ : P₀.PreservesGrade P₁ f₀) (hf₁ : P₁.PreservesGrade P₂ f₁)
    (hf₂ : P₂.PreservesGrade P₃ f₂)
    [Projective P₁.ringModule] [Projective P₂.ringModule] [Projective P₃.ringModule]
    [Mono ((F).map f₀)]
    (hF₀ : ((ShortComplex.mk f₀ f₁ h₀).map F).Exact)
    (hF₁ : ((ShortComplex.mk f₁ f₂ h₁).map F).Exact) :
    Mono f₀ ∧ (ShortComplex.mk f₀ f₁ h₀).Exact ∧
      (ShortComplex.mk f₁ f₂ h₁).Exact ∧
      Projective (P₂.cokernelData P₃ f₂ hf₂).ringModule := by
  obtain ⟨C,l,hl,hlq,hm,he₀,he₁,_⟩ := E.cutGradedTensor_nativeTopCoverCone_exact Q
    P₀ P₁ P₂ P₃ b hb₀ hb₁ hb₂ hb₃ f₀ f₁ f₂ h₀ h₁ hf₀ hf₁ hf₂ hF₀ hF₁
  exact ⟨hm,
    P₀.exact_of_topCoverConeIncoming_exact P₁ P₂ C.source f₀ f₁ h₀ he₀,
    P₁.exact_of_topCoverConeOutgoing_exact P₂ P₃ C.source f₁ f₂ l h₁ he₁,
    P₁.topCoverCone_topCokernel_projective P₂ P₃ f₁ f₂ h₁ hf₂ b
      (E.cutGradedJacobsonOppositeIdeal Q) C l hlq he₁⟩

end ASGinzburg.ZAlgebra.PeriodIso
